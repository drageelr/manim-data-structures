__version__ = '0.1.0'

from .array import *

__all__ = ['MArrayElement', 'MArray']