__version__ = '0.1.1'

from .array import *

__all__ = ['MArrayElement', 'MArray']